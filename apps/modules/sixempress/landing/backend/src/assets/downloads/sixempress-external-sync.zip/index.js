(self["webpackChunk"] = self["webpackChunk"] || []).push([["index"],{

/***/ 435:
/*!**********************!*\
  !*** ./src/index.ts ***!
  \**********************/
/***/ (() => {

// this file exists as entry point for building custom webpack configs
// as we're trying to always extend the wp-env config, we need an entry point to fall to
console.log(21211113313);

/***/ })

},
/******/ __webpack_require__ => { // webpackRuntimeModules
/******/ var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
/******/ var __webpack_exports__ = (__webpack_exec__(435));
/******/ }
]);
//# sourceMappingURL=index.js.map