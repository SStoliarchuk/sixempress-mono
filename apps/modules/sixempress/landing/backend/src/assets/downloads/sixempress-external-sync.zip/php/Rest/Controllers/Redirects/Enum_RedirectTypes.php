<?php

namespace SIXEMPRESS\ExternalSync\Rest\Controllers\Redirects;

defined( 'ABSPATH' ) || exit;

class Enum_RedirectTypes {
	const product   = 1;
}