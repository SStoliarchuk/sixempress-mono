<?php

namespace SIXEMPRESS\ExternalSync\Utils\Enums;

defined( 'ABSPATH' ) || exit;

class Enum_HookTags {
	const get_sync_classes_array = 'sxmpes_get_sync_classes_array';
	const filtered_product_images = 'sxmpes_filtered_product_images';
}